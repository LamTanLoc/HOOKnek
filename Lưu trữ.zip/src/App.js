import React, { useState, useEffect, Fragment } from 'react';
import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Route ,Switch} from 'react-router-dom';
import TrangChu from './pages/TrangChu';
import TrangDanhMucKhoaHoc from './pages/TrangDanhMucKhoaHoc';
import Header from './components/Header';
import HomeTemplate from './templates/HomeTemplate';
import AdminTemplate from './templates/AdminTemplate';
import TrangChiTietKhoaHoc from './pages/TrangChiTietKhoaHoc';
import DangNhap from './pages/DangNhap';
import ThongTinTaiKhoan from './pages/ThongTinTaiKhoan';

function App() {

  return (
    <BrowserRouter>
      <Fragment> 
        <Switch>


          <HomeTemplate path="/trangchu" Component={TrangChu} />
          <HomeTemplate path="/danhmuckhoahoc" Component={TrangDanhMucKhoaHoc} />
          <HomeTemplate path="/chitietkhoahoc/:maKhoaHoc" Component={TrangChiTietKhoaHoc} />
          <HomeTemplate path="/thongtintaikhoan" Component={ThongTinTaiKhoan} />
          <HomeTemplate path="/dangnhap" Component={DangNhap} />
          {/* <HomeTemplate path="/admin" Component={AdinI} /> */}

          

          <HomeTemplate path="/" Component={TrangChu} />

        </Switch>
      </Fragment>
    </BrowserRouter>
  );
}

export default App;


