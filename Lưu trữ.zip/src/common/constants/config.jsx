export const domain = 'http://elearning0706.cybersoft.edu.vn/';
export const accessToken = 'accessToken';