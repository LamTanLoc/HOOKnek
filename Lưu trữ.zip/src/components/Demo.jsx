import React from 'react'

export default function Demo({render,...rest}) {
    return (
        <div>
            demo
            {render('Dep trai nhat qua dat')}
        </div>
    )
}
