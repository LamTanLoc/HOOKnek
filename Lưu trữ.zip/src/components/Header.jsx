import React from 'react';
import {Link,NavLink} from 'react-router-dom'; // tuong tu the a => trong react

export default function Header() {

    let style = {color: 'red'}
    return (
        <div>
            <nav className="navbar navbar-expand-sm bg-dark">
       
                <ul className="navbar-nav">
                    <li className="nav-item">
                        <NavLink to="/trangchu"  className="nav-link" >Cybersorf</NavLink>
                    </li>
                    <li className="nav-item">
                        <NavLink to="/trangchu" activeStyle={style} className="nav-link" >Trang chủ</NavLink>
                    </li>
                    <li className="nav-item">
                        <NavLink to="/danhmuckhoahoc" activeStyle={style}  className="nav-link" >Danh mục khoá học</NavLink>
                    </li>
                    
                    <li className="nav-item">
                        <NavLink to="/chitietkhoahoc" activeStyle={style}  className="nav-link" >Chi tiet khoá học</NavLink>
                    </li>

                    <li className="nav-item">
                        <NavLink to="/dangnhap" activeStyle={style}  className="nav-link" >Đăng nhập</NavLink>
                    </li>
                 
                </ul>
            </nav>

        </div>
    )
}
