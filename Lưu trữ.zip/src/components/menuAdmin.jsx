import React from 'react'

export default function menuAdmin() {
    let style={float: 'left',
     paddingtop: 5,
      paddingleft: 10, 
      color: '#fff',
       marginleft: 'auto',
        // margin-right:'auto',
        //  line-height:'40px' , 
         fontsize: 16, 
        //  font-weight: 'bold',
        //   font-family: 'arial' 
        }
    return (
        <div>
            <div classname="col-md-4 column margintop20">
  <ul classname="nav nav-pills nav-stacked"><div classname="logo_menuchinh"  activeStyle={style} >HOCWEBGIARE.COM</div><div classname="menu-icon"><span>Menu</span></div>
    <li classname="active text-center"><a href="http://hocwebgiare.com"> DANH MỤC KHÓA HỌC</a>
    </li>
    <li><a href="https://hocwebgiare.com/dao-tao-online/Chuyen-vien-website-lanh-nghe-online.html"><span classname="glyphicon glyphicon-chevron-right"> Chuyên viên website lành nghề Online</span></a>
    </li>
    <li><a href="https://hocwebgiare.com/dao-tao-online/Thiet-ke-giao-dien-website-online.html" classname="active2"><span classname="glyphicon glyphicon-chevron-right"> Thiết kế giao diện web Online</span></a>
    </li>
    <li><a href="https://hocwebgiare.com/dao-tao-online/Lap-trinh-PHP-Co-Ban-Online.html"><span classname="glyphicon glyphicon-chevron-right"> Lập trình PHP cơ bản Online</span></a>
    </li>
    <li><a href="https://hocwebgiare.com/dao-tao-online/Lap-trinh-HTML5-CSS3-RWD-Javascript-Bootstrap-Online.html"><span classname="glyphicon glyphicon-chevron-right"> Lập trình HTML5, CSS3, BOOTSTRAP, JS, RWD Online</span></a>
    </li>
  </ul>
</div>


            
        </div>
    )
}
