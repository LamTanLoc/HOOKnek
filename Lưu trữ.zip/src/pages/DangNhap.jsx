import React, { Component } from 'react'
import {Prompt,Redirect} from "react-router-dom";
import {connect} from "react-redux";
// import {Prompt} from "react-router-dom";
import { dangNhapAction } from "../redux/actions/QuanLyNguoiDung";




class DangNhap extends Component {
    handleInput = (e) =>{
        this.setState({
            [e.target.name] : e.target.value
        })
    }

    constructor(props) {
        super(props);
        this.state = {
            taiKhoan: '',
            matKhau: '',
            status: false
        }
    }
    dangNhap = (e) => {

        e.preventDefault();
        // this.props.history.push("/trangchu");
        this.props.dangNhap(this.state);

    }
    render() {
        // if(localStorage.getItem("userLogin")){
        //     return <Redirect to="/trangchu" />
        // }
        return (
            <form onSubmit={this.dangNhap} className="container">
                <h3>ĐĂNG NHẬP</h3>
                <div className="form-group">
                    <span>Tài khoản</span>
                    <input name="taiKhoan" className="form-control"  onChange={this.handleInput}/>
                </div>

                <div className="form-group">
                    <span>Mật khẩu</span>
                    <input type="password" name="matKhau" className="form-control"   onChange={this.handleInput}/>
                </div>

                <div className="form-group">
                    <button type="submit" className="btn btn-success">Đăng nhập</button>
                </div>
                {/* <Prompt when={this.status} message={location => ("Bạn muốn rời khỏi trang này phải không ? Tại sao vậy ?.. đừng mà!!!!")} /> */}

            </form>
        )
    }
}

const mapStateToProps = (state) =>{




}
const mapDispatchToProps = (dispatch) =>{

    return {
        dangNhap :(nguoiDung) =>{
            dispatch(dangNhapAction(nguoiDung));
        }
    }
    
}

export default connect(mapStateToProps,mapDispatchToProps)(DangNhap);

