import React, { Component } from 'react';
import {connect} from "react-redux";
import {layThongTinNguoiDungAction} from '../redux/actions/QuanLyNguoiDung';
import {Redirect} from 'react-router-dom';

 class ThongTinTaiKhoan extends Component {
     componentDidMount(){
         this.props.layThongTinTaiKhoan();
     }



    render() {
        if(!localStorage.getItem("userLogin")){
            return <Redirect to="/trangchu" />
        } 
        return (
            <div>
                {this.props.layThongTinTaiKhoan.hoTen}
                
            </div>
        )
    }
}

const mapStateToProps = (state) =>{
    return {
        thongTinTaiKhoan: state.QuanLyNguoiDungReducer.thongTinTaiKhoan
    }
}

const mapDispatchToProps = (dispatch) =>{
    return {
        layThongTinTaiKhoan : ()=>{
            // lay taiKhoan tu localStorage
            let taiKhoan = JSON.parse(localStorage.getItem("userLogin")).taiKhoan;
            dispatch(layThongTinNguoiDungAction(taiKhoan));
        }
    }
}

export default connect(mapStateToProps,mapDispatchToProps)(ThongTinTaiKhoan);
