import React,{useState,useEffect} from 'react';
import axios from 'axios';


export default function TrangChiTietKhoaHoc(props) {

    let maKhoaHoc = props.match.params.maKhoaHoc;

    let[khoaHoc,setKhoaHoc] = useState({});

     useEffect (()=>{
       

        axios({
            url: `http://svcy.myclass.vn/api/quanlytrungtam/chitietkhoahoc/`+maKhoaHoc,
            method: "GET"
        }).then(result => {
            console.log(result.data);
            // setKhoaHoc(result.data);
        }).catch(error => {
            console.log(error.response.data);
        })
    }, khoaHoc)
         


    return (
        <div>
            trang chi tiet khoa hoc
         ;
            
        </div>
    )
}
