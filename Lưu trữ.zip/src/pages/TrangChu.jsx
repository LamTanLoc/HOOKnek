import React, { useState, useEffect } from 'react'
import Demo from '../components/Demo';
import axios from 'axios';
import {NavLink} from 'react-router-dom';

export default function TrangChu() {
    //danhSachKhoaHoc la 1 mang cac khoa hoc
    let [danhSachKhoaHoc, setDanhSachKhoaHoc] = useState([]);

    useEffect(() => {
        axios({
            url: 'http://svcy.myclass.vn/api/quanlytrungtam/danhsachkhoahoc',
            method: "GET"
        }).then(result => {
            console.log(result.data);
            setDanhSachKhoaHoc(result.data);
        }).catch(error => {
            console.log(error.response.data);
        })
    }, danhSachKhoaHoc)



    return (
        <div className="container">
            <h1>Danh Sách Khoá Học</h1>

            <div className="row">
                {danhSachKhoaHoc.map((khoahoc, i) => {
                    return (

                        <div className="col-md-4" key={i}>
                            <div className="card ">
                                <img className="card-img-top" src={khoahoc.HinhAnh} alt="" />
                                <div className="card-body">
                                    <h4 className="card-title">{khoahoc.TenKhoaHoc}</h4>

                                    <NavLink to={`/chitietkhoahoc/${khoahoc.MaKhoaHoc}`} className="btn btn-danger">Xem chi tiết</NavLink>
                                </div>
                            </div>
                        </div>



                    )
                })}

            </div>
        </div>
    )
}
