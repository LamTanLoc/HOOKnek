import React from 'react'

export default function TrangDanhMucKhoaHoc() {
    return (
        <div>
            danh muc khoa hoc
        </div>
    )
}
