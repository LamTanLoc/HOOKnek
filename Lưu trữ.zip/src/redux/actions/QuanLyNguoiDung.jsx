import * as types from '../constants/QuanLyNguoiDung';
import * as config from '../../common/constants/config';
import axios from 'axios';
import swal from 'sweetalert2';

export const dangNhapAction = (nguoiDung) => {
    return dispatch => {
        axios({
            url: config.domain + `api/QuanLyNguoiDung/DangNhap`,
            method: "POST",
            data: nguoiDung

        }).then(result => {
            console.log(result.data);
            // dang nhap thanh cong thi luu thong tin nguoi dung vao localStorage
            swal.fire('Đăng nhập thành công nhé','success');
            localStorage.setItem("userLogin", JSON.stringify(result.data));
            localStorage.setItem(config.accessToken, result.data.accessToken);

        }).catch(error => {
            console.log(error.response.data);
            swal.fire('ĐU MẸ SAI GÌ RỒI KÌA',error.response.data,'warning');
        })
    }
}


export const layThongTinNguoiDungAction = (taiKhoan) => {
    return dispatch => {
        axios({
            url: config.domain + `api/QuanLyNguoiDung/ThongTinTaiKhoan`,
            method: "POST",
            data: {taiKhoan:taiKhoan},
            headers: {
                "Authorrization": "Bearer" + localStorage.getItem(config.accessToken)
            }

        }).then(result => {
            // console.log(result.data);
           dispatch({
               type: types.LAY_THONG_TIN_NGUOI_DUNG,
               thongTinTaiKhoan : result.data
           })

        }).catch(error => {
            console.log(error.response.data);
        })
    }
}
