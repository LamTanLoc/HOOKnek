import * as types from "../constants/QuanLyNguoiDung";

const stateDefault = {
    thongTinTaiKhoan: {}
}

const QuanLyNguoiDungReducer = (state = stateDefault, action) => {
    // eslint-disable-next-line default-case
    switch(action.type){
        case types.LAY_THONG_TIN_NGUOI_DUNG :{
            state.thongTinTaiKhoan = action.thongTinTaiKhoan;
            return { ...state};
        }
    }
    return { ...state };
}

export default QuanLyNguoiDungReducer;