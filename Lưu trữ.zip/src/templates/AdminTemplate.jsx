import React, { Fragment } from 'react';
import { Route,Redirect} from 'react-router-dom';
import menuAdmin from '../components/menuAdmin';
import Header from '../components/Header';

const AdminLayout = ({ children}) => {

    return (
        <Fragment>

            {/* end */}
            {/* <menuAdmin /> */}

            <Header />
            {children}


           




        </Fragment>
    )

}
const AdminTemplate = ({ Component, ...rest }) => {
    return (
        <Route {...rest} render={(matchProp) => {
            if(localStorage.getItem("UserLogin")){
                return (
                    < AdminLayout>
                    <Component {... rest} />
    
    
                    </AdminLayout>
                )
            }else{
                return <Redirect to="/tranchu" />
            }
            
        }} />
    )

}

export default AdminTemplate;
