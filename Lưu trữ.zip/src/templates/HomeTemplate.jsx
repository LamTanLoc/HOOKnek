import React, { Fragment } from 'react';
import { Route } from 'react-router-dom';
import Header from './../components/Header';



const HomeLayout = ({ children }) => {
    return (
        <Fragment>
            <Header></Header>
            {children}
            {/* {children} tuong tu nhu <ng-content></ng-content> ben angular */}
        </Fragment>

    )
}
const HomeTemplate = ({ Component, ...rest }) => {

    return (
        <Route {...rest} render={(matchProp) => {
            return (
                <HomeLayout >
                    <Component  {...matchProp} />
                    {/* Se dc hien thi tai children cua Home */}

                </HomeLayout>
            )
        }} />


    )

}

export default HomeTemplate;